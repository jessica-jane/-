const db = wx.cloud.database().collection("List")
let date2 = ""
let date1 = ""
let name = ""
let reason = ""
Page({
  data: {
    date2: '2020-12-05',
    date1: '2019-12-05',
    count: null,
  },
  changedate1: function (event) {
    this.setData({
      date1: event.detail.value
    })
    date1 = event.detail.value
  },
  changedate2: function (event) {
    this.setData({
      date2: event.detail.value
    })
    date2 = event.detail.value
  },
  addname(event) {
    name = event.detail.value
  },
  addreason(event) {
    reason = event.detail.value
  },
  // 添加数据
  addData() {
    db.add({
      data: {
        date1: date1,
        date2: date2,
        name: name,
        reason: reason
      },
      success: res => {
        // 在返回结果中会包含新创建的记录的 _id
        this.setData({
          counterId: res._id,
          count: 1
        })
        wx.showToast({
          title: '新增记录成功',
        })
        console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id)
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '新增记录失败'
        })
        console.error('[数据库] [新增记录] 失败：', err)
      }
    })
  },

})