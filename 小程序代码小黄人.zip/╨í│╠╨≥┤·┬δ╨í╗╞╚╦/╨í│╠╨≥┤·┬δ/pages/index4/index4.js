Page({
  data: {
    loginOK: false
  },
  //去登陆页
  denglu() {
    wx.navigateTo({
      url: '/pages/login/login',
    })
  },
  //去注册页
  zhuce() {
    wx.navigateTo({
      url: '/pages/zhuce/zhuce',
    })
  },
  onShow() {
    let user = wx.getStorageSync('user')
    if (user && user.name) {
      this.setData({
        loginOK: true,
        name: user.name
      })
    } else {
      this.setData({
        loginOK: false
      })
    }
  },
  //进入请假页面
  qingjia() {
    wx.navigateTo({
      url: '/pages/p1/p1',
      fail:function(res){
        console.log(res)
      }
    });  
    wx.setStorageSync('user', null)
    let user = wx.getStorageSync('user')
    if (user && user.name) {
      this.setData({
        loginOK: true,
        name: user.name
      })
    } else {
      this.setData({
        loginOK: false
      })
    }
  }
  
})