let app = getApp()

Page({
  data: {
    currentTab: 0,
    items: [
      
      {
        "text": "请假",
        "iconPath": "/images/2-1.png",
        "selectedIconPath": "/images/2.png",
      },
      {
        "iconPath": "/images/1-1.png",
        "selectedIconPath": "/images/1.png",
        "text": "假条"
      },
      
      {
        "iconPath": "/images/3-1.png",
        "selectedIconPath": "/images/3.png",
        "text": "我的"
      }
    ]
  },
  swichNav: function (e) {
    let that = this;
    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },
  onLoad: function (option) {

  }
})
