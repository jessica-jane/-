Page({
  data: {
    detail: '',
    toastHidden: true,
  },
  onLoad(options) {
    console.log("详情页接受的id", options.id),
      wx.cloud.database().collection("List")
        .doc(options.id)
        .get()
        .then(res => {
          console.log("详情页成功", res)
          this.setData({
            detail: res.data
          })
        })
        .catch(res => {
          console.log("详情页失败", res)
        })
  },
  toastBtn: function (e) {
    this.setData({
      toastHidden: false
    })
  },
  toastChange: function (e) {
    this.setData({
      toastHidden: true
    })
  }
})
