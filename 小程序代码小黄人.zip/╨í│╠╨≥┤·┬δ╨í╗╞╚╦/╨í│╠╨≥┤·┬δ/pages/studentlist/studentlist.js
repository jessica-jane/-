Page({
  data: {
    dataList: []
  },
  onLoad() {
    wx.cloud.database().collection('List')
      .get()
      .then(res => {
        console.log("获取成功", res)
        this.setData({
          dataList: res.data
        })
      })
      .catch(res => {
        console.log("获取失败", res)
      })
  },
  // 跳转到详情页
  goDetail(event) {
    console.log("点击获取的数据", event.currentTarget.dataset.item._id)
    wx.navigateTo({
      url: '/pages/studentdetail/studentdetail?id=' + event.currentTarget.dataset.item._id,
    })
  }
})