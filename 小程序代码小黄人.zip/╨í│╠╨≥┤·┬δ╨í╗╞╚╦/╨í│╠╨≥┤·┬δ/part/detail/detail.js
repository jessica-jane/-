Page({
  data: {
    detail: '',
    toastHidden1: true,
    toastHidden2: true
  },
  onLoad(options) {
    console.log("详情页接受的id", options.id),
      wx.cloud.database().collection("List")
        .doc(options.id)
        .get()
        .then(res => {
          console.log("详情页成功", res)
          this.setData({
            detail: res.data
          })
        })
        .catch(res => {
          console.log("详情页失败", res)
        })
  },
  toastBtn1: function (e) {
    this.setData({
      toastHidden1: false
    })
  },
  toastChange1: function (e) {
    this.setData({
      toastHidden1: true
    })
  },
  toastBtn2: function (e) {
    this.setData({
      toastHidden2: false
    })
  },
  toastChange2: function (e) {
    this.setData({
      toastHidden2: true
    })
  }

})