let app = getApp()

Page({
  data: {
    currentTab: 0,
    items: [
      {
        "text": "请假信息",
        "iconPath": "/images/1-1.png",
        "selectedIconPath": "/images/1.png"
      },
      {
        "iconPath": "/images/3-1.png",
        "selectedIconPath": "/images/3.png",
        "text": "我"
      },
    ]
  },
  swichNav: function (e) {
    let that = this;
    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },
  onLoad: function (option) {

  }
})
