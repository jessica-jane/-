const app = getApp()
// pages/index3/index3.js
Page({

  /**
   * 页面的初始数据
   */
  onLoad: function (options) {
    if (app.globalData.openid) {
      this.setData({
        openid: app.globalData.openid
      })
    }
  },
  data: {
    step: 1,
    openid: '',
    name:'',
    count:null,
  },
  backto:function(){
wx.navigateBack({
  dalta:1
})
  },
  onRemove: function () {
    if (this.data.name) {
      const db = wx.cloud.database()
      db.collection('List').doc(this.data.name).remove({
        success: res => {
          wx.showToast({
            title: '删除成功',
          })
          this.setData({
            counterId: '',
            count: null,
          })
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '删除失败',
          })
          console.error('[数据库] [删除记录] 失败：', err)
        }
      })
    } else {
      wx.showToast({
        title: '无记录可删',
      })
    }
  },
})