const db = wx.cloud.database().collection("List")
let date2 = ""
let date1 = ""
let name = ""
let reason = ""
Page({
  data: {
    date2:'2020-12-05',
    date1:'2019-12-05'
  },
  changedate1:function(event){
    this.setData({
   date1:event.detail.value
    })
    date1 = event.detail.value
  },
  changedate2: function (event) {
    this.setData({
      date2: event.detail.value
    })
    date2= event.detail.value
  }, 
   addname(event) {
    name = event.detail.value
  },
  addreason(event) {
    reason = event.detail.value
  },
  // 添加数据
  addData() {
    const db = wx.cloud.database()
    db.collection('List').add({
      data: {
        date1: date1,
        date2: date2,
        name: name,
        reason: reason,
        count: 1
      },
      success(res) {
        console.log("添加成功", res)
      },
      fail(res) {
        console.log("添加失败", res)
      }
    })
  }
})