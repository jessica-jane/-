Page({
  data: {
    loginOK: false
  },
  //去登陆页
  denglu() {
    wx.navigateTo({
      url: '/part/login/login',
    })
  },
  //去注册页
  zhuce() {
    wx.navigateTo({
      url: '/part/zhuce/zhuce',
    })
  },
  onShow() {
    let user = wx.getStorageSync('user')
    if (user && user.name) {
      this.setData({
        loginOK: true,
        name: user.name
      })
    } else {
      this.setData({
        loginOK: false
      })
    }
  },
  //进入请假页面
  qingjia() {
    wx.switchTab({
      url: '../index5/index5'
    });
    wx.setStorageSync('user', null)
    let user = wx.getStorageSync('user')
    if (user && user.name) {
      this.setData({
        loginOK: true,
        name: user.name
      })
    } else {
      this.setData({
        loginOK: false
      })
    }
  }

})